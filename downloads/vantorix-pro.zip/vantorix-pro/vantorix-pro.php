<?php
/**
 * Plugin Name: Vantorix Pro
 * Plugin URI:  https://vantorixtoolkit.vercel.app
 * Description: Premium theme building modules for Vantorix - Toolkit for Elementor. Adds the Archive Builder, Single Post Builder, Search Builder, Dynamic Tags and Template Library.
 * Version:     1.0.0
 * Author:      Vantorix
 * Author URI:  https://vantorixtoolkit.vercel.app
 * Text Domain: vantorix-pro
 * Domain Path: /languages
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires PHP: 7.4
 *
 * @package Vantorix_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'VANTORIX_PRO_VERSION', '1.0.0' );
define( 'VANTORIX_PRO_FILE', __FILE__ );
define( 'VANTORIX_PRO_PATH', plugin_dir_path( __FILE__ ) );
define( 'VANTORIX_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'VANTORIX_PRO_BASENAME', plugin_basename( __FILE__ ) );

/**
 * The license API this site talks to. Change this if you move the server.
 */
if ( ! defined( 'VANTORIX_PRO_API' ) ) {
	define( 'VANTORIX_PRO_API', 'https://licenses.themevally.com/api' );
}

/**
 * Where customers go to buy a license or ask a question.
 */
if ( ! defined( 'VANTORIX_PRO_SITE' ) ) {
	define( 'VANTORIX_PRO_SITE', 'https://vantorixtoolkit.vercel.app' );
}

require_once VANTORIX_PRO_PATH . 'inc/class-license.php';
require_once VANTORIX_PRO_PATH . 'inc/class-license-page.php';
require_once VANTORIX_PRO_PATH . 'inc/class-updater.php';
require_once VANTORIX_PRO_PATH . 'inc/class-modules.php';

/**
 * Boot the add-on once all plugins are loaded.
 *
 * Nothing runs unless the free plugin is active — Pro is an add-on, not a
 * standalone plugin, and it shares the free plugin's helpers and assets.
 */
function vantorix_pro_boot() {
	if ( ! defined( 'VANTORIX_VERSION' ) ) {
		add_action( 'admin_notices', 'vantorix_pro_missing_base_notice' );
		return;
	}

	if ( version_compare( VANTORIX_VERSION, '1.1.0', '<' ) ) {
		add_action( 'admin_notices', 'vantorix_pro_outdated_base_notice' );
		return;
	}

	Vantorix_Pro_License::instance();
	Vantorix_Pro_Updater::instance();

	if ( is_admin() ) {
		Vantorix_Pro_License_Page::instance();
	}

	Vantorix_Pro_Modules::instance();
}
add_action( 'plugins_loaded', 'vantorix_pro_boot', 5 );

/**
 * Tell the site owner the free plugin is required.
 */
function vantorix_pro_missing_base_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	echo '<div class="notice notice-error"><p>';
	echo esc_html__( 'Vantorix Pro needs the free "Vantorix - Toolkit for Elementor" plugin to be installed and active.', 'vantorix-pro' );
	echo '</p></div>';
}

/**
 * Tell the site owner the free plugin is too old.
 */
function vantorix_pro_outdated_base_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	echo '<div class="notice notice-error"><p>';
	echo esc_html__( 'Vantorix Pro needs Vantorix - Toolkit for Elementor version 1.1.0 or newer. Please update the free plugin.', 'vantorix-pro' );
	echo '</p></div>';
}

/**
 * Release the license slot for this domain when the add-on is deactivated.
 */
function vantorix_pro_on_deactivate() {
	if ( class_exists( 'Vantorix_Pro_License' ) ) {
		Vantorix_Pro_License::instance()->deactivate();
	}
}
register_deactivation_hook( __FILE__, 'vantorix_pro_on_deactivate' );
