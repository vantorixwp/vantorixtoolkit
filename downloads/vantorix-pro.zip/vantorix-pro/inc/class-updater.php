<?php
/**
 * Update checker.
 *
 * Because Vantorix Pro is not hosted on WordPress.org, it has to tell WordPress
 * itself when a new version exists. The license server answers with the version
 * number and a download URL that only works for an activated license.
 *
 * @package Vantorix_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Vantorix_Pro_Updater {

	const CACHE_KEY = 'vantorix_pro_update_info';
	const CACHE_TTL = 6 * HOUR_IN_SECONDS;

	/**
	 * Singleton instance.
	 *
	 * @var Vantorix_Pro_Updater|null
	 */
	private static $instance = null;

	/**
	 * Get the shared instance.
	 *
	 * @return Vantorix_Pro_Updater
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Hook into the update pipeline.
	 */
	private function __construct() {
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update' ) );
		add_filter( 'plugins_api', array( $this, 'plugin_info' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( $this, 'flush_cache' ), 10, 0 );
	}

	/**
	 * Add our plugin to WordPress's list of available updates.
	 *
	 * @param object $transient The update_plugins transient.
	 * @return object
	 */
	public function inject_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$info = $this->get_remote_info();

		if ( ! $info || empty( $info['version'] ) ) {
			return $transient;
		}

		if ( version_compare( VANTORIX_PRO_VERSION, $info['version'], '>=' ) ) {
			if ( isset( $transient->response[ VANTORIX_PRO_BASENAME ] ) ) {
				unset( $transient->response[ VANTORIX_PRO_BASENAME ] );
			}

			return $transient;
		}

		$update              = new stdClass();
		$update->slug        = 'vantorix-pro';
		$update->plugin      = VANTORIX_PRO_BASENAME;
		$update->new_version = $info['version'];
		$update->url         = isset( $info['homepage'] ) ? $info['homepage'] : '';
		$update->package     = isset( $info['download_url'] ) ? $info['download_url'] : '';
		$update->tested      = isset( $info['tested'] ) ? $info['tested'] : '';

		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}

		$transient->response[ VANTORIX_PRO_BASENAME ] = $update;

		return $transient;
	}

	/**
	 * Fill in the "View details" popup.
	 *
	 * @param false|object|array $result The result object or array.
	 * @param string             $action The API action being performed.
	 * @param object             $args   Plugin API arguments.
	 * @return false|object|array
	 */
	public function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return $result;
		}

		if ( ! isset( $args->slug ) || 'vantorix-pro' !== $args->slug ) {
			return $result;
		}

		$info = $this->get_remote_info();

		if ( ! $info ) {
			return $result;
		}

		$response                = new stdClass();
		$response->name          = 'Vantorix Pro';
		$response->slug          = 'vantorix-pro';
		$response->version       = isset( $info['version'] ) ? $info['version'] : VANTORIX_PRO_VERSION;
		$response->author        = 'Vantorix';
		$response->homepage      = isset( $info['homepage'] ) ? $info['homepage'] : '';
		$response->download_link = isset( $info['download_url'] ) ? $info['download_url'] : '';
		$response->requires      = isset( $info['requires'] ) ? $info['requires'] : '';
		$response->tested        = isset( $info['tested'] ) ? $info['tested'] : '';
		$response->sections      = array(
			'description' => isset( $info['description'] ) ? wp_kses_post( $info['description'] ) : '',
			'changelog'   => isset( $info['changelog'] ) ? wp_kses_post( $info['changelog'] ) : '',
		);

		return $response;
	}

	/**
	 * Ask the server what the latest release is.
	 *
	 * @return array|false
	 */
	private function get_remote_info() {
		$cached = get_transient( self::CACHE_KEY );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$license = Vantorix_Pro_License::instance();

		$response = wp_remote_post(
			trailingslashit( VANTORIX_PRO_API ) . 'update',
			array(
				'timeout' => 15,
				'body'    => array(
					'product' => 'vantorix-pro',
					'version' => VANTORIX_PRO_VERSION,
					'key'     => $license->get_key(),
					'domain'  => $license->get_domain(),
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			set_transient( self::CACHE_KEY, array(), HOUR_IN_SECONDS );

			return false;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $data ) ) {
			set_transient( self::CACHE_KEY, array(), HOUR_IN_SECONDS );

			return false;
		}

		set_transient( self::CACHE_KEY, $data, self::CACHE_TTL );

		return $data;
	}

	/**
	 * Drop the cached release info after any upgrade runs.
	 */
	public function flush_cache() {
		delete_transient( self::CACHE_KEY );
	}
}
