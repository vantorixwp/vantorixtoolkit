<?php
/**
 * Premium module loader.
 *
 * Boots the modules that ship with this add-on, but only when the license for
 * this domain checks out. The free plugin is told about the licensed state
 * through the vantorix_pro_active filter, which is what makes the Pro modules
 * selectable on its Modules screen.
 *
 * @package Vantorix_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Vantorix_Pro_Modules {

	/**
	 * Singleton instance.
	 *
	 * @var Vantorix_Pro_Modules|null
	 */
	private static $instance = null;

	/**
	 * Map of module slug to the files it needs and the class that boots it.
	 *
	 * @var array
	 */
	private $modules = array(
		'archive_builder' => array(
			'files' => array( 'modules/archive-builder/class-archive-builder.php' ),
			'class' => 'Vantorix_Toolkit_Archive_Builder',
		),
		'single_builder'  => array(
			'files' => array( 'modules/single-builder/class-single-builder.php' ),
			'class' => 'Vantorix_Toolkit_Single_Builder',
		),
		'search_builder'  => array(
			'files' => array( 'modules/search-builder/class-search-builder.php' ),
			'class' => 'Vantorix_Search_Builder',
		),
		'template_library' => array(
			'files' => array( 'modules/template-library/class-template-library.php' ),
			'class' => '\Vantorix_Toolkit\Modules\Template_Library\Module',
		),
	);

	/**
	 * Get the shared instance.
	 *
	 * @return Vantorix_Pro_Modules
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register the hooks the free plugin exposes.
	 */
	private function __construct() {
		add_filter( 'vantorix_pro_active', array( $this, 'filter_pro_active' ) );
		add_action( 'vantorix_modules_loaded', array( $this, 'boot_modules' ) );
		add_action( 'vantorix_register_dynamic_tags', array( $this, 'register_dynamic_tags' ) );
		add_action( 'admin_notices', array( $this, 'license_notice' ) );
	}

	/**
	 * Answer the free plugin's question about whether Pro is usable here.
	 *
	 * @param bool $active Incoming value.
	 * @return bool
	 */
	public function filter_pro_active( $active ) {
		return Vantorix_Pro_License::instance()->is_valid();
	}

	/**
	 * Load each enabled premium module.
	 */
	public function boot_modules() {
		if ( ! Vantorix_Pro_License::instance()->is_valid() ) {
			return;
		}

		foreach ( $this->modules as $slug => $module ) {
			if ( ! Vantorix_Toolkit_Module_Manager::is_module_enabled( $slug ) ) {
				continue;
			}

			foreach ( $module['files'] as $file ) {
				$path = VANTORIX_PRO_PATH . $file;

				if ( file_exists( $path ) ) {
					require_once $path;
				}
			}

			if ( class_exists( $module['class'] ) && method_exists( $module['class'], 'instance' ) ) {
				call_user_func( array( $module['class'], 'instance' ) );
			}
		}
	}

	/**
	 * Register the dynamic tags with Elementor.
	 *
	 * @param object $dynamic_tags_manager Elementor's dynamic tags manager.
	 */
	public function register_dynamic_tags( $dynamic_tags_manager ) {
		if ( ! Vantorix_Pro_License::instance()->is_valid() ) {
			return;
		}

		if ( ! Vantorix_Toolkit_Module_Manager::is_module_enabled( 'dynamic_tags' ) ) {
			return;
		}

		$path = VANTORIX_PRO_PATH . 'modules/dynamic-tags/class-manager.php';

		if ( ! file_exists( $path ) ) {
			return;
		}

		require_once $path;

		if ( class_exists( 'Vantorix_Toolkit_Dynamic_Tags_Manager' ) ) {
			Vantorix_Toolkit_Dynamic_Tags_Manager::instance()->register_tags( $dynamic_tags_manager );
		}
	}

	/**
	 * Show a single, dismissible notice when the license needs attention.
	 *
	 * Nothing on the site breaks when the license is missing — the premium
	 * modules simply stay dormant — so this stays quiet and out of the way.
	 */
	public function license_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$license = Vantorix_Pro_License::instance();

		if ( $license->is_valid() ) {
			return;
		}

		$screen = get_current_screen();

		// Only on the plugins screen and our own pages, so we are not everywhere.
		if ( ! $screen || ( 'plugins' !== $screen->id && false === strpos( $screen->id, 'vantorix' ) ) ) {
			return;
		}

		$status  = $license->get_status();
		$message = __( 'Vantorix Pro is installed but not licensed on this domain. The premium modules stay inactive until a license is applied.', 'vantorix-pro' );

		if ( 'unreachable' === $status['status'] ) {
			$message = __( 'Vantorix Pro could not reach the license server. Premium modules will keep working for a short grace period.', 'vantorix-pro' );
		}
		?>
		<div class="notice notice-warning is-dismissible">
			<p>
				<?php echo esc_html( $message ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=vantorix-license' ) ); ?>">
					<?php esc_html_e( 'Manage license', 'vantorix-pro' ); ?>
				</a>
			</p>
		</div>
		<?php
	}
}
