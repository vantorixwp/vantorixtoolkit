<?php
/**
 * License screen.
 *
 * @package Vantorix_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Vantorix_Pro_License_Page {

	/**
	 * Singleton instance.
	 *
	 * @var Vantorix_Pro_License_Page|null
	 */
	private static $instance = null;

	/**
	 * Notice to show after a form submission.
	 *
	 * @var array{type:string,message:string}|null
	 */
	private $notice = null;

	/**
	 * Get the shared instance.
	 *
	 * @return Vantorix_Pro_License_Page
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Hook up the menu entry and the form handler.
	 */
	private function __construct() {
		add_action( 'admin_menu', array( $this, 'register_page' ), 20 );
		add_action( 'admin_init', array( $this, 'handle_submit' ) );
		add_filter( 'plugin_action_links_' . VANTORIX_PRO_BASENAME, array( $this, 'action_links' ) );
	}

	/**
	 * Add the License submenu under the Vantorix menu.
	 */
	public function register_page() {
		add_submenu_page(
			'vantorix',
			esc_html__( 'License', 'vantorix-pro' ),
			esc_html__( 'License', 'vantorix-pro' ),
			'manage_options',
			'vantorix-license',
			array( $this, 'render' )
		);
	}

	/**
	 * Add a License shortcut on the Plugins screen.
	 *
	 * @param array $links Existing action links.
	 * @return array
	 */
	public function action_links( $links ) {
		$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=vantorix-license' ) ) . '">' . esc_html__( 'License', 'vantorix-pro' ) . '</a>';

		return $links;
	}

	/**
	 * Handle activate / deactivate / recheck submissions.
	 */
	public function handle_submit() {
		if ( ! isset( $_POST['vantorix_license_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vantorix_license_nonce'] ) ), 'vantorix_license' ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified directly above.
		$action = isset( $_POST['vantorix_license_action'] ) ? sanitize_key( wp_unslash( $_POST['vantorix_license_action'] ) ) : '';
		$key    = isset( $_POST['vantorix_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['vantorix_license_key'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$license = Vantorix_Pro_License::instance();

		switch ( $action ) {
			case 'activate':
				$result       = $license->activate( $key );
				$this->notice = array(
					'type'    => $result['success'] ? 'success' : 'error',
					'message' => $result['message'],
				);
				break;

			case 'deactivate':
				$result       = $license->deactivate();
				$this->notice = array(
					'type'    => 'success',
					'message' => $result['message'],
				);
				break;

			case 'recheck':
				$license->refresh();
				$this->notice = array(
					'type'    => 'info',
					'message' => __( 'License status refreshed.', 'vantorix-pro' ),
				);
				break;
		}
	}

	/**
	 * Render the screen.
	 */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$license = Vantorix_Pro_License::instance();
		$status  = $license->get_status();
		$is_dev  = $license->is_development_site();
		$active  = 'valid' === $status['status'];

		$labels = array(
			'valid'       => __( 'Active', 'vantorix-pro' ),
			'invalid'     => __( 'Not valid', 'vantorix-pro' ),
			'inactive'    => __( 'No license applied', 'vantorix-pro' ),
			'unreachable' => __( 'Could not reach the license server', 'vantorix-pro' ),
			'development' => __( 'Development site — running unlocked', 'vantorix-pro' ),
		);

		$label = isset( $labels[ $status['status'] ] ) ? $labels[ $status['status'] ] : $status['status'];
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Vantorix Pro License', 'vantorix-pro' ); ?></h1>

			<?php if ( $this->notice ) : ?>
				<div class="notice notice-<?php echo esc_attr( $this->notice['type'] ); ?>">
					<p><?php echo esc_html( $this->notice['message'] ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( $is_dev ) : ?>
				<div class="notice notice-info inline">
					<p><?php esc_html_e( 'This looks like a local or staging site, so the premium modules run without using up a license slot.', 'vantorix-pro' ); ?></p>
				</div>
			<?php endif; ?>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Status', 'vantorix-pro' ); ?></th>
					<td>
						<strong><?php echo esc_html( $label ); ?></strong>
						<?php if ( ! empty( $status['message'] ) ) : ?>
							<p class="description"><?php echo esc_html( $status['message'] ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'This domain', 'vantorix-pro' ); ?></th>
					<td><code><?php echo esc_html( $license->get_domain() ); ?></code></td>
				</tr>
				<?php if ( $active ) : ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'Package', 'vantorix-pro' ); ?></th>
						<td><?php echo esc_html( $status['package'] ? $status['package'] : '—' ); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Sites allowed', 'vantorix-pro' ); ?></th>
						<td><?php echo esc_html( $status['sites'] > 0 ? $status['sites'] : '—' ); ?></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Expires', 'vantorix-pro' ); ?></th>
						<td><?php echo esc_html( $status['expires'] ? $status['expires'] : __( 'Never', 'vantorix-pro' ) ); ?></td>
					</tr>
				<?php endif; ?>
			</table>

			<form method="post">
				<?php wp_nonce_field( 'vantorix_license', 'vantorix_license_nonce' ); ?>

				<?php if ( $active ) : ?>
					<p>
						<label for="vantorix_license_key"><?php esc_html_e( 'License key', 'vantorix-pro' ); ?></label><br>
						<input type="text" class="regular-text" id="vantorix_license_key" value="<?php echo esc_attr( $this->mask( $status['key'] ) ); ?>" readonly>
					</p>
					<p>
						<button type="submit" name="vantorix_license_action" value="recheck" class="button">
							<?php esc_html_e( 'Re-check now', 'vantorix-pro' ); ?>
						</button>
						<button type="submit" name="vantorix_license_action" value="deactivate" class="button">
							<?php esc_html_e( 'Remove from this site', 'vantorix-pro' ); ?>
						</button>
					</p>
				<?php else : ?>
					<p>
						<label for="vantorix_license_key"><?php esc_html_e( 'License key or ThemeForest purchase code', 'vantorix-pro' ); ?></label><br>
						<input type="text" class="regular-text" id="vantorix_license_key" name="vantorix_license_key" value="" autocomplete="off" spellcheck="false">
					</p>
					<p>
						<button type="submit" name="vantorix_license_action" value="activate" class="button button-primary">
							<?php esc_html_e( 'Activate', 'vantorix-pro' ); ?>
						</button>
					</p>
					<p class="description">
						<?php esc_html_e( 'A ThemeForest purchase code unlocks Pro on one domain. Vantorix packages allow as many domains as the package includes.', 'vantorix-pro' ); ?>
					</p>
				<?php endif; ?>
			</form>

			<div class="vantorix-license-help">
				<h2><?php esc_html_e( 'Do not have a key yet?', 'vantorix-pro' ); ?></h2>
				<p>
					<?php esc_html_e( 'Licenses are issued by hand, so tell us which domain you want to use and we will send a key back.', 'vantorix-pro' ); ?>
				</p>
				<p>
					<a class="button button-primary" href="<?php echo esc_url( VANTORIX_PRO_SITE . '/#pricing' ); ?>" target="_blank" rel="noopener noreferrer">
						<?php esc_html_e( 'See packages and pricing', 'vantorix-pro' ); ?>
					</a>
					<a class="button" href="<?php echo esc_url( add_query_arg( 'domain', rawurlencode( $license->get_domain() ), VANTORIX_PRO_SITE . '/#contact' ) ); ?>" target="_blank" rel="noopener noreferrer">
						<?php esc_html_e( 'Contact us about a license', 'vantorix-pro' ); ?>
					</a>
				</p>
				<p class="description">
					<?php esc_html_e( 'Working locally? Local and staging sites run unlocked and never use a license slot.', 'vantorix-pro' ); ?>
				</p>
			</div>
		</div>

		<style>
			.vantorix-license-help {
				margin-top: 28px;
				padding: 20px 24px;
				background: #fff;
				border: 1px solid #dcdcde;
				border-left: 4px solid #4B2ECC;
				border-radius: 4px;
				max-width: 640px;
			}
			.vantorix-license-help h2 {
				margin-top: 0;
				font-size: 15px;
			}
		</style>
		<?php
	}

	/**
	 * Show only the tail of a key.
	 *
	 * @param string $key Full key.
	 * @return string
	 */
	private function mask( $key ) {
		if ( strlen( $key ) < 8 ) {
			return str_repeat( '•', strlen( $key ) );
		}

		return str_repeat( '•', strlen( $key ) - 4 ) . substr( $key, -4 );
	}
}
