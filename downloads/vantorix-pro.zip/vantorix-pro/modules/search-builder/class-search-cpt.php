<?php
/**
 * Vantorix Search Builder Custom Post Type Configuration
 *
 * @package Vantorix_Toolkit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.Files.FileName -- Search Builder keeps Archive Builder file naming to preserve shared module architecture.
/**
 * Vantorix Search Builder Custom Post Type Configuration.
 */
class Vantorix_Search_CPT {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_post_type' ), 10 );
		add_action( 'init', array( $this, 'add_elementor_support' ), 20 );
	}

	/**
	 * Register Search Builder template CPT.
	 */
	public function register_post_type() {
		$labels = array(
			'name'               => _x( 'Search Templates', 'post type general name', 'vantorix-toolkit' ),
			'singular_name'      => _x( 'Search Template', 'post type singular name', 'vantorix-toolkit' ),
			'menu_name'          => _x( 'Search Builder', 'admin menu', 'vantorix-toolkit' ),
			'name_admin_bar'     => _x( 'Search Template', 'add new on admin bar', 'vantorix-toolkit' ),
			'add_new'            => _x( 'Add New', 'search template', 'vantorix-toolkit' ),
			'add_new_item'       => __( 'Add New Search Template', 'vantorix-toolkit' ),
			'new_item'           => __( 'New Search Template', 'vantorix-toolkit' ),
			'edit_item'          => __( 'Edit Search Template', 'vantorix-toolkit' ),
			'view_item'          => __( 'View Search Template', 'vantorix-toolkit' ),
			'all_items'          => __( 'All Search Templates', 'vantorix-toolkit' ),
			'search_items'       => __( 'Search Search Templates', 'vantorix-toolkit' ),
			'not_found'          => __( 'No search templates found.', 'vantorix-toolkit' ),
			'not_found_in_trash' => __( 'No search templates found in Trash.', 'vantorix-toolkit' ),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => false,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => false, // Explicit "Search Builder" submenu is registered centrally in class-admin-menu.php instead.
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'vantorix_search_tpl' ),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => false,
			'supports'           => array( 'title', 'editor', 'elementor' ),
		);

		register_post_type( 'vantorix_search_tpl', $args );
	}

	/**
	 * Ensure Elementor can edit Search Builder templates.
	 */
	public function add_elementor_support() {
		add_post_type_support( 'vantorix_search_tpl', 'elementor' );
	}
}
// phpcs:enable WordPress.Files.FileName
