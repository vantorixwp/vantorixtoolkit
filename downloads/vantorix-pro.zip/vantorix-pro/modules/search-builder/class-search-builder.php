<?php
/**
 * Vantorix Search Builder Module Orchestrator
 *
 * @package Vantorix_Toolkit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.Files.FileName -- Search Builder keeps Archive Builder file naming to preserve shared module architecture.
/**
 * Vantorix Search Builder Module Orchestrator.
 */
class Vantorix_Search_Builder {

	/**
	 * Class instance holder (Singleton).
	 *
	 * @var Vantorix_Search_Builder|null
	 */
	private static $instance = null;

	/**
	 * CPT Configurer.
	 *
	 * @var Vantorix_Search_CPT
	 */
	public $cpt;

	/**
	 * Frontend Renderer.
	 *
	 * @var Vantorix_Search_Renderer
	 */
	public $renderer;

	/**
	 * Admin settings & duplicate handler.
	 *
	 * @var Vantorix_Search_Admin
	 */
	public $admin;

	/**
	 * Preview & mockup loops generator.
	 *
	 * @var Vantorix_Search_Preview
	 */
	public $preview;

	/**
	 * Get class instance.
	 *
	 * @return Vantorix_Search_Builder Instance.
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ), 20 );
	}

	/**
	 * Bootstrap subclasses.
	 */
	public function init() {
		// Exit early if Elementor is not active.
		if ( ! did_action( 'elementor/loaded' ) && ! class_exists( '\Elementor\Plugin' ) ) {
			return;
		}

		$this->cpt      = new Vantorix_Search_CPT();
		$this->renderer = new Vantorix_Search_Renderer();
		$this->preview  = new Vantorix_Search_Preview();

		if ( is_admin() ) {
			$this->admin = new Vantorix_Search_Admin();
		}
	}
}
// phpcs:enable WordPress.Files.FileName
