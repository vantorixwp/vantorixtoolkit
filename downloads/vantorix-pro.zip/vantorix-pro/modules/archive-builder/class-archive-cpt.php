<?php
/**
 * Vantorix Archive Builder Custom Post Type Configuration
 *
 * @package Vantorix_Toolkit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Vantorix_Toolkit_Archive_CPT {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_post_type' ), 10 );
		add_action( 'init', array( $this, 'add_elementor_support' ), 20 );
	}

	/**
	 * Register CPT vantorix_archive.
	 */
	public function register_post_type() {
		$labels = array(
			'name'               => _x( 'Archive Templates', 'post type general name', 'vantorix-toolkit' ),
			'singular_name'      => _x( 'Archive Template', 'post type singular name', 'vantorix-toolkit' ),
			'menu_name'          => _x( 'Archive Builder', 'admin menu', 'vantorix-toolkit' ),
			'name_admin_bar'     => _x( 'Archive Template', 'add new on admin bar', 'vantorix-toolkit' ),
			'add_new'            => _x( 'Add New', 'archive', 'vantorix-toolkit' ),
			'add_new_item'       => __( 'Add New Archive Template', 'vantorix-toolkit' ),
			'new_item'           => __( 'New Archive Template', 'vantorix-toolkit' ),
			'edit_item'          => __( 'Edit Archive Template', 'vantorix-toolkit' ),
			'view_item'          => __( 'View Archive Template', 'vantorix-toolkit' ),
			'all_items'          => __( 'All Archive Templates', 'vantorix-toolkit' ),
			'search_items'       => __( 'Search Archive Templates', 'vantorix-toolkit' ),
			'not_found'          => __( 'No archive templates found.', 'vantorix-toolkit' ),
			'not_found_in_trash' => __( 'No archive templates found in Trash.', 'vantorix-toolkit' ),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => false,
			'publicly_queryable' => true, // Needed for Elementor preview iframe compatibility
			'show_ui'            => true,
			'show_in_menu'       => 'vantorix', // Nest inside main Vantorix menu
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'vantorix_archive' ),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => false,
			'supports'           => array( 'title', 'editor', 'elementor' ),
		);

		register_post_type( 'vantorix_archive', $args );
	}

	/**
	 * Declare Elementor editor support for this post type.
	 *
	 * Uses WordPress core's add_post_type_support() rather than writing to
	 * Elementor's own 'elementor_cpt_support' option, so the site owner's
	 * Elementor settings are never modified by this plugin.
	 */
	public function add_elementor_support() {
		add_post_type_support( 'vantorix_archive', 'elementor' );
	}
}
