<?php
namespace Vantorix_Toolkit\Modules\Template_Library;

use Vantorix_Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Module {
	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->init();
	}

	private function init() {
		require_once VANTORIX_PRO_PATH . 'modules/template-library/class-type-normalizer.php';
		REST::instance();
		Cache::instance();

		if ( is_admin() ) {
			Admin::instance();
		}

		// Inject into Elementor's editor if needed
		add_action( 'elementor/editor/before_enqueue_scripts', array( $this, 'enqueue_editor_scripts' ) );
		
		// Load assignment orchestrator
		require_once VANTORIX_PRO_PATH . 'modules/template-library/class-template-assignment.php';

		// Load Developer Tools (if developer mode is enabled via setting or constant)
		$is_dev_mode = class_exists( 'Vantorix_Settings' ) && Vantorix_Settings::is_developer_mode();

		if ( $is_dev_mode ) {
			require_once VANTORIX_PRO_PATH . 'modules/template-library/class-developer-tools.php';
			require_once VANTORIX_PRO_PATH . 'modules/template-library/class-package-generator.php';
			Developer_Tools::instance();
			Package_Generator::instance();
		}
	}

	public function enqueue_editor_scripts() {
		// Future: load modal UI inside Elementor editor
	}
}
