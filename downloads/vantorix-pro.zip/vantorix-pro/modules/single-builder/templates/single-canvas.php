<?php
/**
 * Vantorix Single Builder Template Canvas
 *
 * @package Vantorix_Toolkit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template-local variables are not globals

add_action( 'wp_enqueue_scripts', function() {
	wp_enqueue_style( 'vantorix-canvas', VANTORIX_ACC_URL . 'assets/css/canvas.css', array(), VANTORIX_VERSION );
	wp_enqueue_script( 'vantorix-canvas', VANTORIX_ACC_URL . 'assets/js/canvas.js', array(), VANTORIX_VERSION, true );
} );

$template_id = get_query_var( 'vantorix_matched_single_id' );

// Safety fallback
if ( ! $template_id ) {
	$fallback_template = get_query_template( 'single' );
	if ( $fallback_template && file_exists( $fallback_template ) ) {
		include $fallback_template;
	}
	return;
}

$show_header = get_post_meta( $template_id, '_vantorix_single_show_header', true ) !== 'no';
$show_footer = get_post_meta( $template_id, '_vantorix_single_show_footer', true ) !== 'no';

if ( $show_header ) {
	get_header();
} else {
	?>
	<!doctype html>
	<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="https://gmpg.org/xfn/11">
		<?php wp_head(); ?>
	</head>
	<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<?php
}
?>

<main id="es-single-primary" class="es-single-canvas-content es-builder-container elementor-template-full-width" role="main" aria-label="<?php esc_attr_e( 'Single Content', 'vantorix-toolkit' ); ?>">
	<?php
	// Print the Elementor custom layout template content
	vantorix_print_elementor_html( \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $template_id ) );
	?>
</main>

<?php
if ( $show_footer ) {
	get_footer();
} else {
	wp_footer();
	?>
	</body>
	</html>
	<?php
}
