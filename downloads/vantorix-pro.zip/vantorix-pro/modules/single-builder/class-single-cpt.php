<?php
/**
 * Vantorix Single Builder Custom Post Type Configuration
 *
 * @package Vantorix_Toolkit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Vantorix_Toolkit_Single_CPT {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_post_type' ), 10 );
		add_action( 'init', array( $this, 'add_elementor_support' ), 20 );
	}

	/**
	 * Register CPT vantorix_single.
	 */
	public function register_post_type() {
		$labels = array(
			'name'               => _x( 'Single Templates', 'post type general name', 'vantorix-toolkit' ),
			'singular_name'      => _x( 'Single Template', 'post type singular name', 'vantorix-toolkit' ),
			'menu_name'          => _x( 'Single Builder', 'admin menu', 'vantorix-toolkit' ),
			'name_admin_bar'     => _x( 'Single Template', 'add new on admin bar', 'vantorix-toolkit' ),
			'add_new'            => _x( 'Add New', 'single', 'vantorix-toolkit' ),
			'add_new_item'       => __( 'Add New Single Template', 'vantorix-toolkit' ),
			'new_item'           => __( 'New Single Template', 'vantorix-toolkit' ),
			'edit_item'          => __( 'Edit Single Template', 'vantorix-toolkit' ),
			'view_item'          => __( 'View Single Template', 'vantorix-toolkit' ),
			'all_items'          => __( 'All Single Templates', 'vantorix-toolkit' ),
			'search_items'       => __( 'Search Single Templates', 'vantorix-toolkit' ),
			'not_found'          => __( 'No single templates found.', 'vantorix-toolkit' ),
			'not_found_in_trash' => __( 'No single templates found in Trash.', 'vantorix-toolkit' ),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => false,
			'publicly_queryable' => true, // Needed for Elementor preview iframe compatibility
			'show_ui'            => true,
			'show_in_menu'       => 'vantorix', // Nest inside main Vantorix menu
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'vantorix_single' ),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => false,
			'supports'           => array( 'title', 'editor', 'elementor' ),
		);

		register_post_type( 'vantorix_single', $args );
	}

	/**
	 * Declare Elementor editor support for this post type.
	 *
	 * Uses WordPress core's add_post_type_support() rather than writing to
	 * Elementor's own 'elementor_cpt_support' option, so the site owner's
	 * Elementor settings are never modified by this plugin.
	 */
	public function add_elementor_support() {
		add_post_type_support( 'vantorix_single', 'elementor' );
	}
}
