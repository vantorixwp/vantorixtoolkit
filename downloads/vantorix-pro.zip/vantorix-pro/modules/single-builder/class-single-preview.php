<?php
/**
 * Vantorix Single Builder Custom Preview and Mocks Engine
 *
 * @package Vantorix_Toolkit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Vantorix_Toolkit_Single_Preview {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'pre_get_posts', array( $this, 'mock_single_query' ), 5 );
		add_filter( 'the_posts', array( $this, 'inject_dummy_posts_in_editor' ), 10, 2 );
	}

	/**
	 * Check if the current request is editing or previewing a vantorix_single template.
	 *
	 * @return bool True if editing/previewing vantorix_single template, false otherwise.
	 */
	public function is_editing_single_template() {
		if ( is_admin() ) {
			return false;
		}

		// Check if Elementor is active
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return false;
		}

		$post_id = 0;
		// Read-only: identifies whether we're inside Elementor's own gated preview/editor
		// context (is_admin() already excluded above); value is intval-cast and only ever used
		// to look up a post type for a boolean return, never output or acted on.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only Elementor preview context check.
		if ( isset( $_GET['elementor-preview'] ) ) {
			$post_id = intval( $_GET['elementor-preview'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only Elementor preview context check.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only Elementor preview context check.
		} elseif ( isset( $_GET['p'] ) ) {
			$post_id = intval( $_GET['p'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only Elementor preview context check.
		} elseif ( is_singular( 'vantorix_single' ) ) {
			$post_id = get_the_ID();
		}

		if ( $post_id ) {
			$post = get_post( $post_id );
			return ( $post && 'vantorix_single' === $post->post_type );
		}

		return false;
	}

	/**
	 * Mock standard main query parameters inside the editor screen to mimic chosen preview targets.
	 */
	public function mock_single_query( $query ) {
		if ( is_admin() || ! $query->is_main_query() ) {
			return;
		}

		if ( ! $this->is_editing_single_template() ) {
			return;
		}

		// Prevent modifying main query type flags inside Elementor contexts to avoid "Content area not found" error
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only Elementor preview routing check.
		if ( isset( $_GET['elementor-preview'] ) || ( isset( $_GET['action'] ) && 'elementor' === sanitize_text_field( wp_unslash( $_GET['action'] ) ) ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only Elementor AJAX routing check.
		if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) && strpos( sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ), 'elementor' ) !== false ) {
			return;
		}
		if ( class_exists( '\Elementor\Plugin' ) ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
				return;
			}
		}

		// Retrieve the target template ID being designed
		$post_id = 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only Elementor preview context check.
		if ( isset( $_GET['elementor-preview'] ) ) {
			$post_id = intval( $_GET['elementor-preview'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only Elementor preview context check.
		} elseif ( is_singular( 'vantorix_single' ) ) {
			$post_id = get_the_ID();
		}

		if ( ! $post_id ) {
			return;
		}

		// Load configured sample preview variables
		$preview_type = get_post_meta( $post_id, '_vantorix_single_preview_type', true );
		$preview_val  = get_post_meta( $post_id, '_vantorix_single_preview_id', true );

		$query->set( 'posts_per_page', 1 );
		$query->set( 'post_status', 'publish' );
		$query->is_singular = true;
		$query->is_archive  = false;
		$query->is_home     = false;

		// Set target queries depending on selection types
		switch ( $preview_type ) {
			case 'post':
				if ( ! empty( $preview_val ) ) {
					$query->set( 'p', intval( $preview_val ) );
				}
				$query->set( 'post_type', 'post' );
				$query->is_single = true;
				break;

			case 'page':
				if ( ! empty( $preview_val ) ) {
					$query->set( 'page_id', intval( $preview_val ) );
				}
				$query->set( 'post_type', 'page' );
				$query->is_page = true;
				break;

			case 'cpt':
				if ( ! empty( $preview_val ) ) {
					$query->set( 'post_type', sanitize_text_field( $preview_val ) );
				}
				$query->is_single = true;
				break;

			default: // standard post preview
				$query->set( 'post_type', 'post' );
				$query->is_single = true;
				break;
		}
	}

	/**
	 * Inject dummy template posts in editor preview loops if matching post queries returns empty.
	 */
	public function inject_dummy_posts_in_editor( $posts, $query ) {
		if ( is_admin() || ! $query->is_main_query() ) {
			return $posts;
		}

		if ( ! $this->is_editing_single_template() ) {
			return $posts;
		}

		// Inject mock posts context only if queries output empty datasets
		if ( empty( $posts ) ) {
			$posts   = array();
			$posts[] = $this->create_dummy_post_object( 1 );
		}

		return $posts;
	}

	/**
	 * Helper: Construct a dummy WP_Post object mapping.
	 */
	private function create_dummy_post_object( $index ) {
		$post                        = new stdClass();
		$post->ID                    = -9999 - $index;
		$post->post_author           = get_current_user_id() ? get_current_user_id() : 1;
		$post->post_date             = current_time( 'mysql' );
		$post->post_date_gmt         = current_time( 'mysql', 1 );
		/* translators: %d: string */
		$post->post_title            = sprintf( __( 'Sample Preview Post #%d', 'vantorix-toolkit' ), $index );
		$post->post_content          = __( 'This is a sample post content generated automatically by Vantorix Single Preview Engine to prevent empty layouts. You can test your typography, spacing, and post widgets against this dummy content seamlessly.', 'vantorix-toolkit' );
		$post->post_excerpt          = __( 'Sample placeholder text excerpt describing layout styles.', 'vantorix-toolkit' );
		$post->post_status           = 'publish';
		$post->comment_status        = 'open';
		$post->ping_status           = 'open';
		$post->post_password         = '';
		$post->post_name             = 'sample-preview-post-' . $index;
		$post->to_ping               = '';
		$post->pinged                = '';
		$post->post_modified         = current_time( 'mysql' );
		$post->post_modified_gmt     = current_time( 'mysql', 1 );
		$post->post_content_filtered = '';
		$post->post_parent           = 0;
		$post->guid                  = home_url( '/?p=' . $post->ID );
		$post->menu_order            = 0;
		$post->post_type             = 'post';
		$post->post_mime_type        = '';
		$post->comment_count         = 0;
		$post->filter                = 'raw';

		return new WP_Post( $post );
	}
}
