<?php
/**
 * Vantorix - Toolkit for Elementor Dynamic Tag Base Class
 *
 * @package Vantorix_Toolkit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class Vantorix_Dynamic_Tag extends \Elementor\Core\DynamicTags\Tag {

	/**
	 * Get group.
	 *
	 * @return array
	 */
	public function get_group() {
		return array( 'vantorix-post' );
	}

	/**
	 * Get categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY );
	}

	/**
	 * Get centralized Dynamic Data Engine.
	 *
	 * @return \Vantorix_Dynamic_Data
	 */
	protected function get_dynamic_data() {
		return \Vantorix_Dynamic_Data::instance();
	}

	/**
	 * Get post from context.
	 *
	 * @return \WP_Post|null
	 */
	protected function get_post() {
		return $this->get_dynamic_data()->get_current_post();
	}

	/**
	 * Get author from context.
	 *
	 * @return \WP_User|null
	 */
	protected function get_author() {
		return $this->get_dynamic_data()->get_current_author();
	}

	protected function register_advanced_section() {
		parent::register_advanced_section();

		$this->start_controls_section(
			'vantorix_formatting',
			[
				'label' => esc_html__( 'Formatting', 'vantorix-toolkit' ),
			]
		);

		$this->add_control(
			'vantorix_prefix',
			[
				'label' => esc_html__( 'Prefix', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'vantorix_suffix',
			[
				'label' => esc_html__( 'Suffix', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'vantorix_default_value',
			[
				'label' => esc_html__( 'Default Value', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'description' => esc_html__( 'Used if value is truly empty (different from fallback).', 'vantorix-toolkit' ),
			]
		);

		$this->add_control(
			'vantorix_case',
			[
				'label' => esc_html__( 'Text Case', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__( 'Default', 'vantorix-toolkit' ),
					'uppercase' => esc_html__( 'Uppercase', 'vantorix-toolkit' ),
					'lowercase' => esc_html__( 'Lowercase', 'vantorix-toolkit' ),
					'capitalize' => esc_html__( 'Capitalize', 'vantorix-toolkit' ),
				],
				'default' => '',
			]
		);

		$this->add_control(
			'vantorix_trim',
			[
				'label' => esc_html__( 'Trim Whitespace', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'vantorix_strip_html',
			[
				'label' => esc_html__( 'Strip HTML', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'vantorix_strip_shortcodes',
			[
				'label' => esc_html__( 'Strip Shortcodes', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'vantorix_auto_p',
			[
				'label' => esc_html__( 'Auto Paragraph (wpautop)', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'vantorix_url_encode',
			[
				'label' => esc_html__( 'URL Formatting', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__( 'Default', 'vantorix-toolkit' ),
					'encode' => esc_html__( 'URL Encode', 'vantorix-toolkit' ),
					'decode' => esc_html__( 'URL Decode', 'vantorix-toolkit' ),
				],
				'default' => '',
			]
		);

		$this->add_control(
			'vantorix_json_encode',
			[
				'label' => esc_html__( 'JSON Encode', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'vantorix_number_format',
			[
				'label' => esc_html__( 'Number Format', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'description' => esc_html__( 'Format as a number with thousands separator.', 'vantorix-toolkit' ),
			]
		);

		$this->add_control(
			'vantorix_limit',
			[
				'label' => esc_html__( 'Character Limit', 'vantorix-toolkit' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Process formatting for any string value.
	 *
	 * @param string $value
	 * @return string
	 */
	protected function apply_formatting( $value ) {
		$settings = $this->get_settings();

		if ( empty( $value ) && '0' !== $value ) {
			if ( ! empty( $settings['vantorix_default_value'] ) ) {
				$value = $settings['vantorix_default_value'];
			} else {
				return '';
			}
		}

		if ( ! empty( $settings['vantorix_strip_html'] ) && 'yes' === $settings['vantorix_strip_html'] ) {
			$value = wp_strip_all_tags( $value );
		}

		if ( ! empty( $settings['vantorix_strip_shortcodes'] ) && 'yes' === $settings['vantorix_strip_shortcodes'] ) {
			$value = strip_shortcodes( $value );
		}

		if ( ! empty( $settings['vantorix_trim'] ) && 'yes' === $settings['vantorix_trim'] ) {
			$value = trim( $value );
		}

		if ( ! empty( $settings['vantorix_case'] ) ) {
			switch ( $settings['vantorix_case'] ) {
				case 'uppercase':
					$value = strtoupper( $value );
					break;
				case 'lowercase':
					$value = strtolower( $value );
					break;
				case 'capitalize':
					$value = ucwords( strtolower( $value ) );
					break;
			}
		}

		if ( ! empty( $settings['vantorix_number_format'] ) && 'yes' === $settings['vantorix_number_format'] ) {
			if ( is_numeric( $value ) ) {
				$value = number_format_i18n( (float) $value );
			}
		}

		if ( ! empty( $settings['vantorix_limit'] ) ) {
			$limit = absint( $settings['vantorix_limit'] );
			if ( mb_strlen( $value ) > $limit ) {
				$value = mb_substr( $value, 0, $limit ) . '&hellip;';
			}
		}

		if ( ! empty( $settings['vantorix_url_encode'] ) ) {
			if ( 'encode' === $settings['vantorix_url_encode'] ) {
				$value = urlencode( $value );
			} elseif ( 'decode' === $settings['vantorix_url_encode'] ) {
				$value = urldecode( $value );
			}
		}

		if ( ! empty( $settings['vantorix_json_encode'] ) && 'yes' === $settings['vantorix_json_encode'] ) {
			$value = wp_json_encode( $value );
		}

		if ( ! empty( $settings['vantorix_auto_p'] ) && 'yes' === $settings['vantorix_auto_p'] ) {
			$value = wpautop( $value );
		}

		if ( ! empty( $settings['vantorix_prefix'] ) ) {
			$value = $settings['vantorix_prefix'] . $value;
		}

		if ( ! empty( $settings['vantorix_suffix'] ) ) {
			$value .= $settings['vantorix_suffix'];
		}

		return apply_filters( 'vantorix/dynamic_tags/apply_formatting', $value, $settings, $this );
	}

	/**
	 * Render text value safely.
	 *
	 * @param string $value
	 */
	protected function render_text( $value ) {
		$value = $this->apply_formatting( $value );
		if ( ! empty( $value ) || '0' === $value ) {
			echo wp_kses_post( $value );
		}
	}

	/**
	 * Render URL value safely.
	 *
	 * @param string $value
	 */
	protected function render_url( $value ) {
		$value = $this->apply_formatting( $value );
		if ( ! empty( $value ) || '0' === $value ) {
			echo esc_url( $value );
		}
	}

	/**
	 * Render value safely (alias for render_text for backwards compatibility).
	 *
	 * @param string $value
	 */
	protected function render_value( $value ) {
		$this->render_text( $value );
	}
}
