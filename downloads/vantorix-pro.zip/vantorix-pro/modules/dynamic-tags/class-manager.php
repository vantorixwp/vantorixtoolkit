<?php
/**
 * Vantorix - Toolkit for Elementor Dynamic Tags Manager
 *
 * @package Vantorix_Toolkit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Vantorix_Toolkit_Dynamic_Tags_Manager {

	/**
	 * Instance.
	 */
	private static $_instance = null;

	/**
	 * Get instance.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Initialization
	}

	/**
	 * Register Tags.
	 *
	 * @param \Elementor\Core\DynamicTags\Manager $dynamic_tags_manager
	 */
	public function register_tags( $dynamic_tags_manager ) {
		$this->register_groups( $dynamic_tags_manager );
		$this->include_files();
		$this->register_tag_classes( $dynamic_tags_manager );
		
		// Allow third-party developers to register tags
		do_action( 'vantorix/register_dynamic_tags', $dynamic_tags_manager );
	}

	/**
	 * Register tag groups (categories).
	 *
	 * @param \Elementor\Core\DynamicTags\Manager $dynamic_tags_manager
	 */
	private function register_groups( $dynamic_tags_manager ) {
		$groups = array(
			'vantorix-post'     => array( 'title' => esc_html__( 'Vantorix Post', 'vantorix-toolkit' ) ),
			'vantorix-author'   => array( 'title' => esc_html__( 'Vantorix Author', 'vantorix-toolkit' ) ),
			'vantorix-site'     => array( 'title' => esc_html__( 'Vantorix Site', 'vantorix-toolkit' ) ),
			'vantorix-term'     => array( 'title' => esc_html__( 'Vantorix Term', 'vantorix-toolkit' ) ),
			'vantorix-search'   => array( 'title' => esc_html__( 'Vantorix Search', 'vantorix-toolkit' ) ),
			'vantorix-archive'  => array( 'title' => esc_html__( 'Vantorix Archive', 'vantorix-toolkit' ) ),
			'vantorix-user'     => array( 'title' => esc_html__( 'Vantorix User', 'vantorix-toolkit' ) ),
			'vantorix-comments' => array( 'title' => esc_html__( 'Vantorix Comments', 'vantorix-toolkit' ) ),
			'vantorix-media'    => array( 'title' => esc_html__( 'Vantorix Media', 'vantorix-toolkit' ) ),
			'vantorix-url'      => array( 'title' => esc_html__( 'Vantorix URL', 'vantorix-toolkit' ) ),
			'vantorix-woo'      => array( 'title' => esc_html__( 'Vantorix WooCommerce', 'vantorix-toolkit' ) ),
			'vantorix-acf'      => array( 'title' => esc_html__( 'Vantorix ACF', 'vantorix-toolkit' ) ),
			'vantorix-meta'     => array( 'title' => esc_html__( 'Vantorix Meta', 'vantorix-toolkit' ) ),
		);

		foreach ( $groups as $group_id => $group_args ) {
			$dynamic_tags_manager->register_group( $group_id, $group_args );
		}
	}

	/**
	 * Include tag files.
	 */
	private function include_files() {
		// Centralized Data Engine
		require_once VANTORIX_ACC_PATH . 'inc/managers/class-dynamic-data.php';

		// Base Class
		require_once VANTORIX_PRO_PATH . 'modules/dynamic-tags/class-base-tag.php';
		require_once VANTORIX_PRO_PATH . 'modules/dynamic-tags/class-data-tag.php';

		// Categories
		$files = array(
			'post-title',
			'post-excerpt',
			'post-content',
			'post-url',
			'post-slug',
			'post-featured-image',
			'post-date',
			'post-info',
			'author-info',
			'author-url',
			'author-profile-picture',
			'site-title',
			'site-tagline',
			'site-url',
			'site-logo',
			'site-date-time',
			'term-info',
			'term-url',
			'search-info',
			'archive-info',
			'archive-url',
			'user-info',
			'user-profile-picture',
			'comments-info',
			'media-info',
			'url-info',
			'post-meta',
			'acf-text',
			'acf-image',
			'acf-gallery',
			'acf-url',
			'woo-product-price',
			'woo-product-image',
			'woo-product-rating',
			'woo-product-sku',
						'woo-product-stock',
			'post-navigation',
			'post-navigation-url',
			'current-date-time',
			'request-info',
			'smart-tags',
			'author-meta',
			'term-meta',
			'user-meta',
			'woo-product-title',
			'woo-product-url',
			'woo-product-attributes',
			'woo-product-terms',
		);

		foreach ( $files as $file ) {
			$path = VANTORIX_PRO_PATH . 'modules/dynamic-tags/tags/class-' . $file . '.php';
			if ( file_exists( $path ) ) {
				require_once $path;
			}
		}
	}

	/**
	 * Register tag classes.
	 *
	 * @param \Elementor\Core\DynamicTags\Manager $dynamic_tags_manager
	 */
	private function register_tag_classes( $dynamic_tags_manager ) {
		$tags = array(
			'Vantorix_Dynamic_Tag_Post_Title',
			'Vantorix_Dynamic_Tag_Post_Excerpt',
			'Vantorix_Dynamic_Tag_Post_Content',
			'Vantorix_Dynamic_Tag_Post_Url',
			'Vantorix_Dynamic_Tag_Post_Slug',
			'Vantorix_Dynamic_Tag_Post_Featured_Image',
			'Vantorix_Dynamic_Tag_Post_Date',
			'Vantorix_Dynamic_Tag_Post_Info',
			'Vantorix_Dynamic_Tag_Author_Info',
			'Vantorix_Dynamic_Tag_Author_Url',
			'Vantorix_Dynamic_Tag_Author_Profile_Picture',
			'Vantorix_Dynamic_Tag_Site_Title',
			'Vantorix_Dynamic_Tag_Site_Tagline',
			'Vantorix_Dynamic_Tag_Site_Url',
			'Vantorix_Dynamic_Tag_Site_Logo',
			'Vantorix_Dynamic_Tag_Site_Date_Time',
			'Vantorix_Dynamic_Tag_Term_Info',
			'Vantorix_Dynamic_Tag_Term_Url',
			'Vantorix_Dynamic_Tag_Search_Info',
			'Vantorix_Dynamic_Tag_Archive_Info',
			'Vantorix_Dynamic_Tag_Archive_Url',
			'Vantorix_Dynamic_Tag_User_Info',
			'Vantorix_Dynamic_Tag_User_Profile_Picture',
			'Vantorix_Dynamic_Tag_Comments_Info',
			'Vantorix_Dynamic_Tag_Media_Info',
			'Vantorix_Dynamic_Tag_Url_Info',
			'Vantorix_Dynamic_Tag_Post_Meta',
			'Vantorix_Dynamic_Tag_Acf_Text',
			'Vantorix_Dynamic_Tag_Acf_Image',
			'Vantorix_Dynamic_Tag_Acf_Gallery',
			'Vantorix_Dynamic_Tag_Acf_Url',
			'Vantorix_Dynamic_Tag_Woo_Product_Price',
			'Vantorix_Dynamic_Tag_Woo_Product_Image',
			'Vantorix_Dynamic_Tag_Woo_Product_Rating',
			'Vantorix_Dynamic_Tag_Woo_Product_Sku',
						'Vantorix_Dynamic_Tag_Woo_Product_Stock',
			'Vantorix_Dynamic_Tag_Post_Navigation',
			'Vantorix_Dynamic_Tag_Post_Navigation_Url',
			'Vantorix_Dynamic_Tag_Current_Date_Time',
			'Vantorix_Dynamic_Tag_Request_Info',
			'Vantorix_Dynamic_Tag_Smart_Tags',
			'Vantorix_Dynamic_Tag_Author_Meta',
			'Vantorix_Dynamic_Tag_Term_Meta',
			'Vantorix_Dynamic_Tag_User_Meta',
			'Vantorix_Dynamic_Tag_Woo_Product_Title',
			'Vantorix_Dynamic_Tag_Woo_Product_Url',
			'Vantorix_Dynamic_Tag_Woo_Product_Attributes',
			'Vantorix_Dynamic_Tag_Woo_Product_Terms',
		);

		foreach ( $tags as $tag_class ) {
			if ( class_exists( $tag_class ) ) {
				$dynamic_tags_manager->register( new $tag_class() );
			}
		}
	}
}
