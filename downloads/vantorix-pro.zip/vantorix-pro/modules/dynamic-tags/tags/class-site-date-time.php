<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vantorix_Dynamic_Tag_Site_Date_Time extends Vantorix_Dynamic_Tag {

	public function get_name() {
		return 'site-date-time';
	}

	public function get_title() {
		return esc_html__( 'Site Date/Time Info', 'vantorix-toolkit' );
	}

	public function get_group() {
		return 'vantorix-site';
	}

	public function get_categories() {
		return array( \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY );
	}

	protected function register_controls() {
		
		$this->add_control(
			"info_type",
			[
				"label" => esc_html__( "Information", "vantorix-toolkit" ),
				"type" => \Elementor\Controls_Manager::SELECT,
				"options" => [
					"admin_email" => esc_html__( "Admin Email", "vantorix-toolkit" ),
					"language" => esc_html__( "Language", "vantorix-toolkit" ),
					"timezone" => esc_html__( "Timezone", "vantorix-toolkit" ),
					"date_format" => esc_html__( "Date Format", "vantorix-toolkit" ),
					"time_format" => esc_html__( "Time Format", "vantorix-toolkit" ),
				],
				"default" => "admin_email",
			]
		);
	}
	public function render() {
		
		$settings = $this->get_settings();
		$info_type = isset( $settings["info_type"] ) ? $settings["info_type"] : "admin_email";
		
		$value = "";
		switch ( $info_type ) {
			case "admin_email":
				$value = get_option( "admin_email" );
				break;
			case "language":
				$value = get_bloginfo( "language" );
				break;
			case "timezone":
				$value = wp_timezone_string();
				break;
			case "date_format":
				$value = get_option( "date_format" );
				break;
			case "time_format":
				$value = get_option( "time_format" );
				break;
		}
		$this->render_text( $value );
	}
}
