<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vantorix_Dynamic_Tag_Comments_Info extends Vantorix_Dynamic_Tag {

	public function get_name() {
		return 'comments-info';
	}

	public function get_title() {
		return esc_html__( 'Comments Info', 'vantorix-toolkit' );
	}

	public function get_group() {
		return 'vantorix-comments';
	}

	public function get_categories() {
		return array( \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY );
	}

	protected function register_controls() {
		
		$this->add_control(
			"info_type",
			[
				"label" => esc_html__( "Information", "vantorix-toolkit" ),
				"type" => \Elementor\Controls_Manager::SELECT,
				"options" => [
					"count" => esc_html__( "Comment Count", "vantorix-toolkit" ),
					"open" => esc_html__( "Are Comments Open?", "vantorix-toolkit" ),
					"last_date" => esc_html__( "Last Comment Date", "vantorix-toolkit" ),
				],
				"default" => "count",
			]
		);
	}
	public function render() {
		
		$settings = $this->get_settings();
		$info_type = isset( $settings["info_type"] ) ? $settings["info_type"] : "count";
		
		$post = $this->get_post();
		if ( ! $post ) { return; }
		
		$value = "";
		switch ( $info_type ) {
			case "count":
				$value = $post->comment_count;
				break;
			case "open":
				$value = comments_open( $post->ID ) ? esc_html__( "Yes", "vantorix-toolkit" ) : esc_html__( "No", "vantorix-toolkit" );
				break;
			case "last_date":
				$comments = get_comments( [ "post_id" => $post->ID, "status" => "approve", "number" => 1 ] );
				if ( ! empty( $comments ) ) {
					$value = get_comment_date( "", $comments[0]->comment_ID );
				}
				break;
		}
		$this->render_text( $value );
	}
}
