<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vantorix_Dynamic_Tag_Post_Info extends Vantorix_Dynamic_Tag {

	public function get_name() {
		return 'post-info';
	}

	public function get_title() {
		return esc_html__( 'Post Info', 'vantorix-toolkit' );
	}

	public function get_group() {
		return 'vantorix-post';
	}

	public function get_categories() {
		return array( \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY );
	}

	protected function register_controls() {

		$this->add_control(
			'info_type',
			array(
				'label'   => esc_html__( 'Information', 'vantorix-toolkit' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'id'                 => esc_html__( 'ID', 'vantorix-toolkit' ),
					'type'               => esc_html__( 'Post Type', 'vantorix-toolkit' ),
					'status'             => esc_html__( 'Status', 'vantorix-toolkit' ),
					'comment_count'      => esc_html__( 'Comment Count', 'vantorix-toolkit' ),
					'word_count'         => esc_html__( 'Word Count', 'vantorix-toolkit' ),
					'reading_time'       => esc_html__( 'Reading Time', 'vantorix-toolkit' ),
					'format'             => esc_html__( 'Post Format', 'vantorix-toolkit' ),
					'sticky'             => esc_html__( 'Is Sticky?', 'vantorix-toolkit' ),
					'password_protected' => esc_html__( 'Is Password Protected?', 'vantorix-toolkit' ),
				),
				'default' => 'id',
			)
		);
	}
	public function render() {

		$settings  = $this->get_settings();
		$info_type = isset( $settings['info_type'] ) ? $settings['info_type'] : 'id';
		$post      = $this->get_post();
		if ( ! $post ) {
			return; }

		$value = '';
		switch ( $info_type ) {
			case 'id':
				$value = $post->ID;
				break;
			case 'type':
				$value = $post->post_type;
				break;
			case 'status':
				$value = $post->post_status;
				break;
			case 'comment_count':
				$value = $post->comment_count;
				break;
			case 'word_count':
				$value = str_word_count( wp_strip_all_tags( $post->post_content ) );
				break;
			case 'reading_time':
				$words   = str_word_count( wp_strip_all_tags( $post->post_content ) );
				$minutes = ceil( $words / 200 );
				/* translators: %s: Number of minutes */
				$value   = sprintf( _n( '%s min', '%s mins', $minutes, 'vantorix-toolkit' ), $minutes );
				break;
			case 'format':
				$value = get_post_format( $post->ID ) ?: 'standard';
				break;
			case 'sticky':
				$value = is_sticky( $post->ID ) ? esc_html__( 'Yes', 'vantorix-toolkit' ) : esc_html__( 'No', 'vantorix-toolkit' );
				break;
			case 'password_protected':
				$value = post_password_required( $post->ID ) ? esc_html__( 'Yes', 'vantorix-toolkit' ) : esc_html__( 'No', 'vantorix-toolkit' );
				break;
		}
		$this->render_text( $value );
	}
}
