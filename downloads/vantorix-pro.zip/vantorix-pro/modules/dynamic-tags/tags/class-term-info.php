<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vantorix_Dynamic_Tag_Term_Info extends Vantorix_Dynamic_Tag {

	public function get_name() {
		return 'term-info';
	}

	public function get_title() {
		return esc_html__( 'Term Info', 'vantorix-toolkit' );
	}

	public function get_group() {
		return 'vantorix-term';
	}

	public function get_categories() {
		return array( \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY );
	}

	protected function register_controls() {
		
		$this->add_control(
			"info_type",
			[
				"label" => esc_html__( "Information", "vantorix-toolkit" ),
				"type" => \Elementor\Controls_Manager::SELECT,
				"options" => [
					"name" => esc_html__( "Name", "vantorix-toolkit" ),
					"description" => esc_html__( "Description", "vantorix-toolkit" ),
					"id" => esc_html__( "ID", "vantorix-toolkit" ),
					"parent" => esc_html__( "Parent Term", "vantorix-toolkit" ),
					"count" => esc_html__( "Count", "vantorix-toolkit" ),
				],
				"default" => "name",
			]
		);
	}
	public function render() {
		
		$settings = $this->get_settings();
		$info_type = isset( $settings["info_type"] ) ? $settings["info_type"] : "name";
		
		$term = $this->get_dynamic_data()->get_current_term();
		
		if ( ! $term || ! isset( $term->term_id ) ) { return; }
		
		$value = "";
		switch ( $info_type ) {
			case "name":
				$value = $term->name;
				break;
			case "description":
				$value = $term->description;
				break;
			case "id":
				$value = $term->term_id;
				break;
			case "parent":
				$value = $term->parent ? get_term( $term->parent )->name : "";
				break;
			case "count":
				$value = $term->count;
				break;
		}
		
		$this->render_text( $value );
	}
}
