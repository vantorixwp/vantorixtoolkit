<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vantorix_Dynamic_Tag_Post_Slug extends Vantorix_Dynamic_Tag {

	public function get_name() {
		return 'post-slug';
	}

	public function get_title() {
		return esc_html__( 'Post Slug', 'vantorix-toolkit' );
	}

	public function get_group() {
		return 'vantorix-post';
	}

	public function get_categories() {
		return array( \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY );
	}

	public function render() {
		
		$post = $this->get_post();
		if ( ! $post ) { return; }
		$this->render_text( $post->post_name );
	}
}
