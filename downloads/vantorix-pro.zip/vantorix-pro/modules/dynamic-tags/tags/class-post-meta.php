<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vantorix_Dynamic_Tag_Post_Meta extends Vantorix_Dynamic_Tag {

	public function get_name() {
		return 'post-meta';
	}

	public function get_title() {
		return esc_html__( 'Post Custom Meta', 'vantorix-toolkit' );
	}

	public function get_group() {
		return 'vantorix-meta';
	}

	public function get_categories() {
		return array( \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY );
	}

	protected function register_controls() {
		
		$this->add_control(
			"meta_key",
			[
				"label" => esc_html__( "Meta Key", "vantorix-toolkit" ),
				"type" => \Elementor\Controls_Manager::TEXT,
			]
		);
	}
	public function render() {
		
		$settings = $this->get_settings();
		$meta_key = isset( $settings["meta_key"] ) ? $settings["meta_key"] : "";
		if ( empty( $meta_key ) ) { return; }
		
		$post = $this->get_post();
		if ( ! $post ) { return; }
		
		$value = get_post_meta( $post->ID, $meta_key, true );
		if ( is_array( $value ) ) {
			$value = implode( ", ", $value );
		}
		$this->render_text( $value );
	}
}
