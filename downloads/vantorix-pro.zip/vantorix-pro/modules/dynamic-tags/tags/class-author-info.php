<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Vantorix_Dynamic_Tag_Author_Info extends Vantorix_Dynamic_Tag {

	public function get_name() {
		return 'author-info';
	}

	public function get_title() {
		return esc_html__( 'Author Info', 'vantorix-toolkit' );
	}

	public function get_group() {
		return 'vantorix-author';
	}

	public function get_categories() {
		return array( \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY );
	}

	protected function register_controls() {
		
		$this->add_control(
			"info_type",
			[
				"label" => esc_html__( "Information", "vantorix-toolkit" ),
				"type" => \Elementor\Controls_Manager::SELECT,
				"options" => [
					"display_name" => esc_html__( "Display Name", "vantorix-toolkit" ),
					"first_name" => esc_html__( "First Name", "vantorix-toolkit" ),
					"last_name" => esc_html__( "Last Name", "vantorix-toolkit" ),
					"bio" => esc_html__( "Bio", "vantorix-toolkit" ),
					"email" => esc_html__( "Email", "vantorix-toolkit" ),
					"id" => esc_html__( "ID", "vantorix-toolkit" ),
				],
				"default" => "display_name",
			]
		);
	}
	public function render() {
		
		$settings = $this->get_settings();
		$info_type = isset( $settings["info_type"] ) ? $settings["info_type"] : "display_name";
		$author = $this->get_author();
		if ( ! $author ) { return; }
		
		$value = "";
		switch ( $info_type ) {
			case "display_name":
				$value = $author->display_name;
				break;
			case "first_name":
				$value = $author->first_name;
				break;
			case "last_name":
				$value = $author->last_name;
				break;
			case "bio":
				$value = $author->description;
				break;
			case "email":
				$value = $author->user_email;
				break;
			case "id":
				$value = $author->ID;
				break;
		}
		
		$this->render_text( $value );
	}
}
