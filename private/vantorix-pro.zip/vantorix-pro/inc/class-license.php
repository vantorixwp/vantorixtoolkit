<?php
/**
 * License client.
 *
 * Talks to the Vantorix license API, caches the answer, and decides whether the
 * premium modules may load on this domain.
 *
 * Design notes:
 * - The cached status is trusted for 24 hours so a slow or unreachable server
 *   never takes a customer's site down.
 * - If the server cannot be reached at all, the last known good status is kept
 *   for a grace period rather than failing closed.
 * - Local, staging and development hosts never consume a license slot.
 *
 * @package Vantorix_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Vantorix_Pro_License {

	const OPTION_KEY    = 'vantorix_pro_license';
	const CACHE_KEY     = 'vantorix_pro_license_status';
	const CACHE_TTL     = DAY_IN_SECONDS;
	const GRACE_PERIOD  = 7 * DAY_IN_SECONDS;

	/**
	 * Singleton instance.
	 *
	 * @var Vantorix_Pro_License|null
	 */
	private static $instance = null;

	/**
	 * Resolved status for this request.
	 *
	 * @var array|null
	 */
	private $status = null;

	/**
	 * Get the shared instance.
	 *
	 * @return Vantorix_Pro_License
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Hook up the daily re-check.
	 */
	private function __construct() {
		add_action( 'vantorix_pro_license_cron', array( $this, 'refresh' ) );

		if ( ! wp_next_scheduled( 'vantorix_pro_license_cron' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'vantorix_pro_license_cron' );
		}
	}

	/**
	 * The domain a license is bound to.
	 *
	 * www and non-www are treated as the same site so nobody burns two slots
	 * on one installation.
	 *
	 * @return string
	 */
	public function get_domain() {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );

		if ( ! $host ) {
			return '';
		}

		$host = strtolower( $host );

		if ( 0 === strpos( $host, 'www.' ) ) {
			$host = substr( $host, 4 );
		}

		return $host;
	}

	/**
	 * Is this a local or staging site?
	 *
	 * These run unlocked and are never counted against the license, because
	 * developers legitimately need to build and test somewhere.
	 *
	 * @return bool
	 */
	public function is_development_site() {
		$host = $this->get_domain();

		if ( '' === $host || 'localhost' === $host ) {
			return true;
		}

		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return true;
		}

		$dev_suffixes = array( '.local', '.test', '.localhost', '.invalid', '.example' );

		foreach ( $dev_suffixes as $suffix ) {
			if ( substr( $host, -strlen( $suffix ) ) === $suffix ) {
				return true;
			}
		}

		$dev_prefixes = array( 'localhost.', 'staging.', 'stage.', 'dev.', 'test.' );

		foreach ( $dev_prefixes as $prefix ) {
			if ( 0 === strpos( $host, $prefix ) ) {
				return true;
			}
		}

		if ( function_exists( 'wp_get_environment_type' ) && in_array( wp_get_environment_type(), array( 'local', 'development', 'staging' ), true ) ) {
			return true;
		}

		// Local by Flywheel and similar tools set this.
		if ( defined( 'WP_LOCAL_DEV' ) && WP_LOCAL_DEV ) {
			return true;
		}

		/**
		 * Filter whether this install counts as a development site.
		 *
		 * @param bool   $is_dev Current decision.
		 * @param string $host   Normalised host name.
		 */
		return (bool) apply_filters( 'vantorix_pro_is_development_site', false, $host );
	}

	/**
	 * The stored license record.
	 *
	 * @return array
	 */
	public function get_stored() {
		$stored = get_option( self::OPTION_KEY, array() );

		return wp_parse_args(
			is_array( $stored ) ? $stored : array(),
			array(
				'key'        => '',
				'type'       => 'license',
				'status'     => 'inactive',
				'package'    => '',
				'expires'    => '',
				'sites'      => 0,
				'domain'     => '',
				'checked_at' => 0,
				'message'    => '',
			)
		);
	}

	/**
	 * The license key entered by the site owner.
	 *
	 * @return string
	 */
	public function get_key() {
		$stored = $this->get_stored();

		return $stored['key'];
	}

	/**
	 * Resolve the current status, using cache where possible.
	 *
	 * @return array
	 */
	public function get_status() {
		if ( null !== $this->status ) {
			return $this->status;
		}

		if ( $this->is_development_site() ) {
			$stored           = $this->get_stored();
			$stored['status'] = 'development';
			$this->status     = $stored;

			return $this->status;
		}

		$cached = get_transient( self::CACHE_KEY );

		if ( is_array( $cached ) ) {
			$this->status = $cached;

			return $this->status;
		}

		$this->status = $this->refresh();

		return $this->status;
	}

	/**
	 * Are the premium modules allowed to run right now?
	 *
	 * @return bool
	 */
	public function is_valid() {
		$status = $this->get_status();

		return in_array( $status['status'], array( 'valid', 'development' ), true );
	}

	/**
	 * Ask the server to activate this domain against a key.
	 *
	 * @param string $key License key or Envato purchase code.
	 * @return array{success:bool,message:string}
	 */
	public function activate( $key ) {
		$key = trim( $key );

		if ( '' === $key ) {
			return array(
				'success' => false,
				'message' => __( 'Please enter your license key.', 'vantorix-pro' ),
			);
		}

		$response = $this->request(
			'activate',
			array(
				'key'    => $key,
				'domain' => $this->get_domain(),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		if ( empty( $response['valid'] ) ) {
			$this->store(
				array(
					'key'     => $key,
					'status'  => 'invalid',
					'message' => isset( $response['message'] ) ? $response['message'] : '',
				)
			);

			return array(
				'success' => false,
				'message' => isset( $response['message'] ) ? $response['message'] : __( 'That license key could not be activated.', 'vantorix-pro' ),
			);
		}

		$this->store(
			array(
				'key'     => $key,
				'type'    => isset( $response['type'] ) ? $response['type'] : 'license',
				'status'  => 'valid',
				'package' => isset( $response['package'] ) ? $response['package'] : '',
				'expires' => isset( $response['expires'] ) ? $response['expires'] : '',
				'sites'   => isset( $response['sites'] ) ? (int) $response['sites'] : 1,
				'domain'  => $this->get_domain(),
				'message' => '',
			)
		);

		return array(
			'success' => true,
			'message' => __( 'License activated. Premium modules are now available.', 'vantorix-pro' ),
		);
	}

	/**
	 * Release this domain's slot.
	 *
	 * @return array{success:bool,message:string}
	 */
	public function deactivate() {
		$stored = $this->get_stored();

		if ( '' !== $stored['key'] ) {
			$this->request(
				'deactivate',
				array(
					'key'    => $stored['key'],
					'domain' => $this->get_domain(),
				)
			);
		}

		delete_option( self::OPTION_KEY );
		delete_transient( self::CACHE_KEY );
		$this->status = null;

		return array(
			'success' => true,
			'message' => __( 'License removed from this site.', 'vantorix-pro' ),
		);
	}

	/**
	 * Re-check with the server and refresh the cache.
	 *
	 * @return array The resolved status record.
	 */
	public function refresh() {
		$stored = $this->get_stored();

		if ( '' === $stored['key'] ) {
			set_transient( self::CACHE_KEY, $stored, self::CACHE_TTL );

			return $stored;
		}

		$response = $this->request(
			'validate',
			array(
				'key'    => $stored['key'],
				'domain' => $this->get_domain(),
			)
		);

		if ( is_wp_error( $response ) ) {
			/*
			 * The server could not be reached. Keep the last known good status
			 * for the grace period so an outage on our side never breaks a
			 * customer's site. Re-check sooner than usual.
			 */
			$age = time() - (int) $stored['checked_at'];

			if ( 'valid' === $stored['status'] && $age < self::GRACE_PERIOD ) {
				set_transient( self::CACHE_KEY, $stored, HOUR_IN_SECONDS * 6 );

				return $stored;
			}

			$stored['status']  = 'unreachable';
			$stored['message'] = $response->get_error_message();
			set_transient( self::CACHE_KEY, $stored, HOUR_IN_SECONDS );

			return $stored;
		}

		$stored['status']     = empty( $response['valid'] ) ? 'invalid' : 'valid';
		$stored['package']    = isset( $response['package'] ) ? $response['package'] : $stored['package'];
		$stored['expires']    = isset( $response['expires'] ) ? $response['expires'] : $stored['expires'];
		$stored['sites']      = isset( $response['sites'] ) ? (int) $response['sites'] : $stored['sites'];
		$stored['message']    = isset( $response['message'] ) ? $response['message'] : '';
		$stored['domain']     = $this->get_domain();
		$stored['checked_at'] = time();

		update_option( self::OPTION_KEY, $stored, false );
		set_transient( self::CACHE_KEY, $stored, self::CACHE_TTL );
		$this->status = $stored;

		return $stored;
	}

	/**
	 * Persist a partial license record.
	 *
	 * @param array $data Fields to merge into the stored record.
	 */
	private function store( $data ) {
		$stored               = wp_parse_args( $data, $this->get_stored() );
		$stored['checked_at'] = time();

		update_option( self::OPTION_KEY, $stored, false );
		set_transient( self::CACHE_KEY, $stored, self::CACHE_TTL );
		$this->status = $stored;
	}

	/**
	 * Turn a transport failure into a message the site owner can act on.
	 *
	 * WordPress passes cURL's wording straight through, and strings like
	 * "error 60: SSL certificate ... unable to get local issuer certificate"
	 * tell a site owner nothing about what to do next.
	 *
	 * @param WP_Error $error The original error.
	 * @return WP_Error
	 */
	private function explain_transport_error( $error ) {
		$raw = $error->get_error_message();

		if ( false !== stripos( $raw, 'certificate' ) || false !== stripos( $raw, 'ssl' ) ) {
			return new WP_Error(
				'vantorix_pro_ssl',
				__( 'This site could not verify the license server\'s security certificate. This usually happens on local or staging installs that are missing an up-to-date certificate bundle. Local sites run unlocked anyway, so you can ignore this while developing. On a live site, ask your host to update the server\'s CA certificates.', 'vantorix-pro' )
			);
		}

		if ( false !== stripos( $raw, 'resolve host' ) || false !== stripos( $raw, 'could not resolve' ) ) {
			return new WP_Error(
				'vantorix_pro_dns',
				__( 'The license server address could not be reached. Check that this site has outgoing internet access.', 'vantorix-pro' )
			);
		}

		if ( false !== stripos( $raw, 'timed out' ) || false !== stripos( $raw, 'timeout' ) ) {
			return new WP_Error(
				'vantorix_pro_timeout',
				__( 'The license server did not respond in time. Please try again in a few minutes.', 'vantorix-pro' )
			);
		}

		return new WP_Error(
			'vantorix_pro_transport',
			sprintf(
				/* translators: %s: underlying connection error. */
				__( 'Could not reach the license server (%s).', 'vantorix-pro' ),
				$raw
			)
		);
	}

	/**
	 * Call the license API.
	 *
	 * @param string $endpoint Endpoint name.
	 * @param array  $body     Request body.
	 * @return array|WP_Error Decoded response, or an error.
	 */
	private function request( $endpoint, $body ) {
		$body['product'] = 'vantorix-pro';
		$body['version'] = VANTORIX_PRO_VERSION;

		/**
		 * Filter the license API base URL.
		 *
		 * Useful while testing against a staging license server.
		 *
		 * @param string $url Base URL, without a trailing slash.
		 */
		$api_url = apply_filters( 'vantorix_pro_api_url', VANTORIX_PRO_API );

		$response = wp_remote_post(
			trailingslashit( $api_url ) . $endpoint,
			array(
				'timeout' => 15,
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $this->explain_transport_error( $response );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $data ) ) {
			return new WP_Error(
				'vantorix_pro_bad_response',
				sprintf(
					/* translators: %s: the license API address. */
					__( 'The license server sent something other than a licence response. Check that %s is the REST address of the Vantorix License Server, not a normal web page.', 'vantorix-pro' ),
					esc_url( trailingslashit( $api_url ) . $endpoint )
				)
			);
		}

		if ( $code >= 500 ) {
			return new WP_Error( 'vantorix_pro_server_error', __( 'The license server is temporarily unavailable.', 'vantorix-pro' ) );
		}

		return $data;
	}
}
